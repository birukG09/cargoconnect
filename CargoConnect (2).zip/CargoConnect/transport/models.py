from django.db import models
from accounts.models import User  # Assuming your custom user model is in 'accounts'
from accounts.models import Service

class Cargo(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    weight = models.FloatField()
    origin = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='transport_bookings')  # Changed related_name to avoid clash
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name='transport_bookings')  # Ensured uniqueness with related_name
    booking_date = models.DateTimeField()
    status = models.CharField(max_length=50, default='Pending')  # E.g., Pending, Confirmed, etc.

    pickup_location = models.CharField(max_length=255, blank=True, null=True)
    additional_message = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Booking by {self.user.username} for {self.service.name}"




# New ServiceProvider model
class ServiceProvider(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='service_provider')
    business_name = models.CharField(max_length=100)
    service_description = models.TextField()
    location = models.CharField(max_length=200)
    contact_info = models.CharField(max_length=100)

    def __str__(self):
        return self.business_name
