from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponse
from .models import Cargo, Booking, ServiceProvider  # Assuming the model is here
from accounts.forms import ServiceProviderForm  # Importing the form we created

# Default view for /transport/
def transport_home(request):
    return HttpResponse("Welcome to the Transport section!")

# View to list all cargo
def cargo_list(request):
    cargos = Cargo.objects.all().values()
    return JsonResponse(list(cargos), safe=False)

# View to list all bookings
def booking_list(request):
    bookings = Booking.objects.all().values()
    return JsonResponse(list(bookings), safe=False)

# View for Service Provider form
def service_provider_form_view(request):
    if request.method == "POST":
        form = ServiceProviderForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('service_provider_dashboard')  # Change 'service_provider_dashboard' to the URL name for the Service Provider page
    else:
        form = ServiceProviderForm()

    return render(request, 'transport/service_provider_form.html', {'form': form})

# View for Service Provider Dashboard
def service_provider_dashboard(request):
    return render(request, 'transport/service_provider_dashboard.html')  # Adjust template if needed
