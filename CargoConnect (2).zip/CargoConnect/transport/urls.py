from django.urls import path
from . import views  # Import all views at once

urlpatterns = [
    path('', views.transport_home, name='transport-home'),
    path('cargo/', views.cargo_list, name='cargo-list'),
    path('bookings/', views.booking_list, name='booking-list'),
    path('service-provider-form/', views.service_provider_form_view, name='service_provider_form'),
    path('service-provider/dashboard/', views.service_provider_dashboard, name='service_provider_dashboard'),  # Service provider dashboard
]
