from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, Service
from .models import Booking

# Sign-Up form for Service Providers
class ServiceProviderSignUpForm(UserCreationForm):
    phone_number = forms.CharField(max_length=15, required=True)
    profile_picture = forms.ImageField(required=False)

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2', 'phone_number', 'profile_picture']


# Service Form for posting services
class ServiceForm(forms.ModelForm):
    class Meta:
        model = Service
        fields = ['name', 'description', 'price', 'category', 'location']  # Ensure 'category' is included if it's in the model

class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['booking_date', 'pickup_location', 'additional_message']
        

