from django.urls import path
from .views import service_list
from .views import service_detail
from .views import (
    user_login,
    choose_role,
    customer_signup,
    service_provider_signup,
    register_customer,
    register_service_provider,
    user_logout,
    service_list,
    post_service,
    service_provider_dashboard,
    customer_dashboard,
    book_service  # Make sure this is added
)


urlpatterns = [
    path('login/', user_login, name='login'),
    path('choose-role/', choose_role, name='choose_role'),
    path('customer-signup/', customer_signup, name='customer_signup'),
    path('service-provider-signup/', service_provider_signup, name='service_provider_signup'),
    path('register-customer/', register_customer, name='register_customer'),
    path('register-service-provider/', register_service_provider, name='register_service_provider'),
    path('logout/', user_logout, name='logout'),
    path('service-list/', service_list, name='service_list'),
    path('post-service/', post_service, name='post_service'),
    path('service-provider-dashboard/', service_provider_dashboard, name='service_provider_dashboard'),
    path('customer-dashboard/', customer_dashboard, name='customer_dashboard'),
    path('service-detail/<int:service_id>/', service_detail, name='service_detail'),
    path('book-service/<int:service_id>/', book_service, name='book_service'),
]
