from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .forms import ServiceProviderSignUpForm, ServiceForm
from .models import User, Service  # Assuming User and Service models are here
from django.shortcuts import get_object_or_404
from .forms import BookingForm


# Customer Registration View
def register_customer(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.user_type = 'customer'  # Set user type
            user.save()
            login(request, user)
            messages.success(request, "Registration successful!")
            return redirect('service_list')  # Redirect customer to service list
    else:
        form = UserCreationForm()

    return render(request, 'accounts/register_customer.html', {'form': form})


# Customer Sign Up View
def customer_signup(request):
    if request.method == "POST":
        username = request.POST.get("username")
        email = request.POST.get("email")  # Get email from form
        password = request.POST.get("password")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken.")
            return redirect("customer_signup")

        user = User.objects.create_user(username=username, email=email, password=password)
        user.user_type = "customer"
        user.save()

        login(request, user)
        return redirect("customer_dashboard")

    return render(request, "accounts/customer_signup.html")


# Service Provider Registration View
def register_service_provider(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.user_type = 'service_provider'  # Set user type
            user.save()
            login(request, user)
            messages.success(request, "Registration successful!")
            return redirect('post_service')  # Redirect to post_service after successful login
    else:
        form = UserCreationForm()

    return render(request, 'accounts/register_service_provider.html', {'form': form})

# Service Detail View
def service_detail(request, service_id):
    service = get_object_or_404(Service, id=service_id)
    return render(request, 'accounts/service_detail.html', {'service': service})

# Service Provider Sign Up View
def service_provider_signup(request):
    if request.method == "POST":
        username = request.POST.get("username")
        email = request.POST.get("email")  # Get email from form
        password = request.POST.get("password")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken.")
            return redirect("service_provider_signup")

        user = User.objects.create_user(username=username, email=email, password=password)
        user.user_type = "service_provider"
        user.save()

        login(request, user)
        return redirect("service_provider_dashboard")

    return render(request, "accounts/service_provider_signup.html")

# Add this function in your accounts/views.py file

def service_list(request):
    services = Service.objects.all()  # Assuming you want to show all services
    return render(request, 'accounts/service_list.html', {'services': services})


# Service Provider Post Service View
@login_required
def post_service(request):
    if request.method == 'POST':
        form = ServiceForm(request.POST)
        if form.is_valid():
            service = form.save(commit=False)
            service.provider = request.user  # Set the provider to the logged-in user
            service.save()
            messages.success(request, "Service posted successfully!")
            return redirect('service_provider_dashboard')  # Redirect to dashboard after posting
    else:
        form = ServiceForm()

    return render(request, 'accounts/post_service.html', {'form': form})

# User Login View
def user_login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)

            # Redirect based on user type
            if user.user_type == "customer":
                return redirect("customer_dashboard")
            elif user.user_type == "service_provider":
                return redirect("service_provider_dashboard")
        else:
            messages.error(request, "Invalid username or password.")

    return render(request, "accounts/login.html")


def service_provider_dashboard(request):
    return render(request, 'accounts/service_provider_dashboard.html')  # Render a dashboard template   

def customer_dashboard(request):
    services = Service.objects.all()  # Fetch all available services
    return render(request, 'accounts/customer_dashboard.html', {'services': services})


def choose_role(request):
    if request.method == 'POST':
        role = request.POST['role']

        # Redirect user to the respective registration page
        if role == 'customer':
            return redirect('customer_signup')
        elif role == 'service_provider':
            return redirect('service_provider_signup')
        else:
            messages.error(request, "Invalid role selected.")
            return redirect('choose_role')

    return render(request, 'accounts/choose_role.html')
   
@login_required
def book_service(request, service_id):
    service = get_object_or_404(Service, id=service_id)
    
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            # Save the booking
            booking = form.save(commit=False)
            booking.customer = request.user  # Assuming user is logged in
            booking.service = service
            booking.save()
            return redirect('booking_confirmation')  # Redirect to a confirmation page (create one if needed)
    else:
        form = BookingForm()
    
    return render(request, 'accounts/book_service.html', {'form': form, 'service': service})


# User Logout View
@login_required
def user_logout(request):
    logout(request)
    messages.success(request, "Logout successful!")
    return redirect('home')
