from django.contrib import admin
from .models import User, Service

# UserAdmin class to manage User model in the admin interface
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'user_type', 'phone_number', 'address', 'profile_picture')
    search_fields = ('username', 'email', 'user_type')
    list_filter = ('user_type',)

admin.site.register(User, UserAdmin)


# ServiceAdmin class to manage Service model in the admin interface
# Removed 'created_at' and 'updated_at' from list_display
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'price', 'get_rating', 'get_provider')  # Corrected provider field display
    list_filter = ('provider',)
    search_fields = ('name', 'description', 'provider__username')

    def get_rating(self, obj):
        return obj.rating if obj.rating is not None else "Not Rated"
    
    get_rating.admin_order_field = 'rating'  
    get_rating.short_description = 'Rating'

    def get_provider(self, obj):
        return obj.provider.username  # Display the username of the provider
    
    get_provider.admin_order_field = 'provider'  
    get_provider.short_description = 'Provider'

admin.site.register(Service, ServiceAdmin)
