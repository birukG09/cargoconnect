from django.db import models
from django.contrib.auth.models import AbstractUser  # Fixed import statement

class User(AbstractUser):
    USER_TYPE_CHOICES = [
        ('customer', 'Customer'),
        ('service_provider', 'Service Provider'),
    ]
    
    user_type = models.CharField(max_length=20, choices=USER_TYPE_CHOICES)
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    profile_picture = models.ImageField(upload_to='profile_pics/', blank=True, null=True)

    def __str__(self):
        return self.username


class Service(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    available = models.BooleanField(default=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    rating = models.DecimalField(max_digits=3, decimal_places=2, null=True, blank=True)
    provider = models.ForeignKey(User, on_delete=models.CASCADE, related_name="services")  # Added related_name
    category = models.CharField(max_length=100, blank=True, null=True)
    location = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return self.name


class Booking(models.Model):
    customer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='account_bookings')  # Added related_name
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name='account_bookings')  # Ensured uniqueness with related_name
    booking_date = models.DateTimeField()
    status = models.CharField(max_length=50, default='Pending')  # E.g., Pending, Confirmed, etc.
    
    pickup_location = models.CharField(max_length=255, blank=True, null=True)
    additional_message = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Booking by {self.customer.username} for {self.service.name}"





