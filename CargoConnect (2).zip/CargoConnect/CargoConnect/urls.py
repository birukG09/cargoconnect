# CargoConnect/urls.py
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import render

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('accounts.urls')),  # Include accounts URLs
    path('', lambda request: render(request, 'accounts/home.html'), name='home'),  # Landing page
]
