from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from flask_login import login_required, current_user
from app import db
from models import Booking, Location
from datetime import datetime

booking_bp = Blueprint('booking', __name__)

@booking_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'customer':
        bookings = Booking.query.filter_by(customer_id=current_user.id).all()
    elif current_user.role == 'transporter':
        bookings = Booking.query.filter_by(transporter_id=current_user.id).all()
    else:
        bookings = Booking.query.all()
    return render_template('booking/dashboard.html', bookings=bookings)

@booking_bp.route('/booking/create', methods=['GET', 'POST'])
@login_required
def create_booking():
    if request.method == 'POST':
        booking = Booking(
            customer_id=current_user.id,
            pickup_location=request.form.get('pickup_location'),
            delivery_location=request.form.get('delivery_location'),
            cargo_type=request.form.get('cargo_type'),
            weight=float(request.form.get('weight')),
            estimated_price=float(request.form.get('estimated_price'))
        )
        db.session.add(booking)
        db.session.commit()
        payment_method = request.form.get('payment_method')
        return redirect(url_for('payment.initialize_payment', booking_id=booking.id, method=payment_method))
    return render_template('booking/create.html')

@booking_bp.route('/booking/<int:booking_id>/track')
@login_required
def track(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    locations = Location.query.filter_by(booking_id=booking_id).order_by(Location.timestamp.desc()).all()
    return render_template('booking/track.html', booking=booking, locations=locations)

@booking_bp.route('/api/location/update', methods=['POST'])
@login_required
def update_location():
    if current_user.role != 'transporter':
        return jsonify({'error': 'Unauthorized'}), 403
        
    data = request.get_json()
    location = Location(
        booking_id=data['booking_id'],
        latitude=data['latitude'],
        longitude=data['longitude']
    )
    db.session.add(location)
    db.session.commit()
    return jsonify({'status': 'success'})
