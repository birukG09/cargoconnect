from flask import Blueprint, request, jsonify, redirect, url_for
from flask_login import login_required, current_user
from app import db
from models import Payment, Booking
import requests
import os
import uuid
from config.payment import CHAPA_CONFIG

payment_bp = Blueprint('payment', __name__)

CHAPA_API_URL = CHAPA_CONFIG['API_URL']
CHAPA_SECRET_KEY = CHAPA_CONFIG['SECRET_KEY']
TELEBIRR_APP_ID = os.environ.get('TELEBIRR_APP_ID', 'YOUR_TELEBIRR_APP_ID')
TELEBIRR_APP_KEY = os.environ.get('TELEBIRR_APP_KEY', 'YOUR_TELEBIRR_APP_KEY')

#CHAPA_API_URL = "https://api.chapa.co/v1/transaction/initialize"
TELEBIRR_API_URL = "https://api.telebirr.com/v1/payment/initialize"

@payment_bp.route('/payment/initialize/<int:booking_id>/<string:method>', methods=['POST'])
@login_required
def initialize_payment(booking_id, method):
    booking = Booking.query.get_or_404(booking_id)

    if method not in ['chapa', 'telebirr']:
        return jsonify({'error': 'Invalid payment method'}), 400

    transaction_ref = f"cargo-{booking_id}-{uuid.uuid4().hex[:8]}"

    if method == 'chapa':
        return initialize_chapa_payment(booking, transaction_ref)
    else:
        return initialize_telebirr_payment(booking, transaction_ref)

def initialize_chapa_payment(booking, transaction_ref):
    headers = {
        "Authorization": f"Bearer {CHAPA_SECRET_KEY}",
        "Content-Type": "application/json"
    }

    data = {
        "amount": str(booking.estimated_price),
        "currency": "ETB",
        "email": current_user.email,
        "first_name": current_user.name,
        "tx_ref": transaction_ref,
        "callback_url": url_for('payment.verify_chapa', _external=True),
        "return_url": url_for('booking.dashboard', _external=True)
    }

    response = requests.post(CHAPA_API_URL, json=data, headers=headers)

    if response.status_code == 200:
        response_data = response.json()
        payment = Payment(
            booking_id=booking.id,
            amount=booking.estimated_price,
            transaction_id=transaction_ref,
            payment_method='chapa'
        )
        db.session.add(payment)
        db.session.commit()
        return redirect(response_data['data']['checkout_url'])

    return jsonify({'error': 'Chapa payment initialization failed'}), 400

def initialize_telebirr_payment(booking, transaction_ref):
    data = {
        "appId": TELEBIRR_APP_ID,
        "appKey": TELEBIRR_APP_KEY,
        "nonce": uuid.uuid4().hex,
        "timestamp": str(int(time.time())),
        "notifyUrl": url_for('payment.verify_telebirr', _external=True),
        "returnUrl": url_for('booking.dashboard', _external=True),
        "subject": f"Cargo Booking #{booking.id}",
        "outTradeNo": transaction_ref,
        "totalAmount": str(int(booking.estimated_price * 100)),  # Amount in cents
        "shortCode": "your_short_code",
        "timeoutExpress": "30"
    }

    # Sign the request (implementation depends on TeleBirr's requirements)
    # data["sign"] = calculate_signature(data)

    response = requests.post(TELEBIRR_API_URL, json=data)

    if response.status_code == 200:
        response_data = response.json()
        payment = Payment(
            booking_id=booking.id,
            amount=booking.estimated_price,
            transaction_id=transaction_ref,
            payment_method='telebirr'
        )
        db.session.add(payment)
        db.session.commit()
        return redirect(response_data['toPayUrl'])

    return jsonify({'error': 'TeleBirr payment initialization failed'}), 400

@payment_bp.route('/payment/verify/chapa', methods=['POST'])
def verify_chapa():
    data = request.get_json()
    transaction_id = data.get('tx_ref')

    payment = Payment.query.filter_by(transaction_id=transaction_id, payment_method='chapa').first()
    if payment and data.get('status') == 'success':
        payment.status = 'completed'
        db.session.commit()
        return jsonify({'status': 'success'})

    return jsonify({'error': 'Payment verification failed'}), 400

@payment_bp.route('/payment/verify/telebirr', methods=['POST'])
def verify_telebirr():
    data = request.get_json()
    transaction_id = data.get('outTradeNo')

    payment = Payment.query.filter_by(transaction_id=transaction_id, payment_method='telebirr').first()
    if payment and data.get('tradeStatus') == 'SUCCESS':
        payment.status = 'completed'
        db.session.commit()
        return jsonify({'status': 'success'})

    return jsonify({'error': 'Payment verification failed'}), 400