from flask import Blueprint, render_template, abort
from flask_login import login_required, current_user
from app import db
from models import User, Booking, Payment

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/admin/dashboard')
@login_required
def dashboard():
    if current_user.role != 'admin':
        abort(403)
    
    total_bookings = Booking.query.count()
    active_transporters = User.query.filter_by(role='transporter').count()
    recent_bookings = Booking.query.order_by(Booking.created_at.desc()).limit(10).all()
    recent_payments = Payment.query.order_by(Payment.created_at.desc()).limit(10).all()
    
    return render_template('admin/dashboard.html',
                         total_bookings=total_bookings,
                         active_transporters=active_transporters,
                         recent_bookings=recent_bookings,
                         recent_payments=recent_payments)

@admin_bp.route('/admin/users')
@login_required
def users():
    if current_user.role != 'admin':
        abort(403)
    
    users = User.query.all()
    return render_template('admin/users.html', users=users)

@admin_bp.route('/admin/bookings')
@login_required
def bookings():
    if current_user.role != 'admin':
        abort(403)
    
    bookings = Booking.query.all()
    return render_template('admin/bookings.html', bookings=bookings)
