
# Payment Gateway Documentation

## Chapa API Gateway

Base URL: `https://api.chapa.co/v1`

### Initialize Payment
- **Endpoint**: `/transaction/initialize`
- **Method**: POST
- **Headers**:
  - `Authorization`: Bearer YOUR_SECRET_KEY
  - `Content-Type`: application/json
- **Request Body**:
```json
{
    "amount": "100",
    "currency": "ETB",
    "email": "customer@email.com",
    "first_name": "John",
    "last_name": "Doe",
    "tx_ref": "unique-transaction-reference",
    "callback_url": "https://your-callback-url.com/payment/verify",
    "return_url": "https://your-return-url.com/order/success"
}
```
- **Response**:
```json
{
    "status": "success",
    "data": {
        "checkout_url": "https://checkout.chapa.co/checkout/payment/..."
    }
}
```

### Verify Payment
- **Endpoint**: `/transaction/verify/{tx_ref}`
- **Method**: GET
- **Headers**:
  - `Authorization`: Bearer YOUR_SECRET_KEY

## TeleBirr API Gateway

Base URL: `https://api.telebirr.com/v1`

### Initialize Payment
- **Endpoint**: `/payment/initialize`
- **Method**: POST
- **Request Body**:
```json
{
    "appId": "YOUR_APP_ID",
    "appKey": "YOUR_APP_KEY",
    "nonce": "random-unique-string",
    "timestamp": "unix-timestamp",
    "notifyUrl": "https://your-notify-url.com/payment/verify",
    "returnUrl": "https://your-return-url.com/order/success",
    "subject": "Payment Description",
    "outTradeNo": "unique-transaction-reference",
    "totalAmount": "10000",
    "shortCode": "your-short-code",
    "timeoutExpress": "30"
}
```

### Payment Notification
TeleBirr will send a POST request to your notify URL with the following structure:
```json
{
    "outTradeNo": "your-transaction-reference",
    "tradeNo": "telebirr-transaction-id",
    "tradeStatus": "SUCCESS",
    "totalAmount": "10000"
}
```

Note: Make sure to keep your API keys and credentials secure using the Replit Secrets tool.
