import os
import requests
from uuid import uuid4
from datetime import datetime
from typing import Optional, Dict, Any
from app import db
from models import Payment

class ChapaService:
    BASE_URL = "https://api.chapa.co/v1"
    
    def __init__(self):
        self.secret_key = os.environ.get('CHAPA_SECRET_KEY')
        self.headers = {
            'Authorization': f'Bearer {self.secret_key}',
            'Content-Type': 'application/json'
        }

    def initialize_payment(self, amount: float, email: str, first_name: str, 
                         last_name: str, tx_ref: str, callback_url: str,
                         return_url: str) -> Dict[str, Any]:
        """Initialize a payment transaction with Chapa"""
        payload = {
            'amount': str(amount),
            'currency': 'ETB',
            'email': email,
            'first_name': first_name,
            'last_name': last_name,
            'tx_ref': tx_ref,
            'callback_url': callback_url,
            'return_url': return_url,
            'customization[title]': 'FreightBook Payment',
            'customization[description]': 'Payment for freight transport booking'
        }
        
        try:
            response = requests.post(
                f"{self.BASE_URL}/transaction/initialize",
                headers=self.headers,
                json=payload,
                timeout=30
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {
                'status': 'failed',
                'message': f'Payment initialization failed: {str(e)}',
                'data': None
            }

    def verify_payment(self, tx_ref: str) -> Dict[str, Any]:
        """Verify a payment transaction with Chapa"""
        try:
            response = requests.get(
                f"{self.BASE_URL}/transaction/verify/{tx_ref}",
                headers=self.headers,
                timeout=30
            )
            
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {
                'status': 'failed',
                'message': f'Verification failed: {str(e)}',
                'data': None
            }

    def handle_charge_webhook(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Handle charge webhook notifications from Chapa"""
        tx_ref = payload.get('tx_ref')
        status = payload.get('status')
        event = payload.get('event')

        if not tx_ref:
            return {'status': 'error', 'message': 'Missing tx_ref'}

        payment = Payment.query.filter_by(tx_ref=tx_ref).first()
        if not payment:
            return {'status': 'error', 'message': 'Payment not found'}

        # Update payment status based on event
        if event == 'charge.success' and status == 'success':
            payment.status = 'completed'
            payment.booking.payment_status = 'paid'
            payment.booking.status = 'confirmed'
        elif event in ['charge.refunded', 'charge.reversed']:
            payment.status = status
            payment.booking.payment_status = status
        elif event == 'charge.failed/cancelled':
            payment.status = 'failed'
            payment.booking.payment_status = 'failed'
        
        db.session.commit()
        return {'status': 'success', 'message': f'Payment {status} processed'}

    @staticmethod
    def generate_transaction_reference() -> str:
        """Generate a unique transaction reference"""
        return f"FB-{datetime.now().strftime('%Y%m%d')}-{str(uuid4())[:8]}"
