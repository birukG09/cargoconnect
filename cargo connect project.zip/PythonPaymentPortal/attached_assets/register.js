
document.addEventListener('DOMContentLoaded', function() {
    const driverFields = document.getElementById('driver_fields');
    const userTypeRadios = document.getElementsByName('user_type');
    
    userTypeRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            driverFields.style.display = this.value === 'driver' ? 'block' : 'none';
            
            // Toggle required attribute on driver fields
            const driverInputs = driverFields.querySelectorAll('input, select');
            driverInputs.forEach(input => {
                input.required = this.value === 'driver';
            });
        });
    });
});
