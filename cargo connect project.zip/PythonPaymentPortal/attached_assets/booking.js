document.addEventListener('DOMContentLoaded', function() {
    const weightInput = document.getElementById('weight');
    const cargoTypeSelect = document.getElementById('cargo_type');
    const amountInput = document.getElementById('amount');
    const bookingForm = document.getElementById('bookingForm');

    // Base rate per kilometer (in ETB)
    const BASE_RATE = 25;

    // Weight rate per kg (in ETB)
    const WEIGHT_RATE = 5;

    // Cargo type multipliers
    const CARGO_MULTIPLIERS = {
        'general': 1.0,
        'perishable': 1.5,
        'fragile': 1.8,
        'heavy': 2.0
    };

    // Function to calculate estimated cost
    function calculateEstimatedCost() {
        const distance = window.getDistance() || 0; // Get distance from map.js
        const weight = parseFloat(weightInput.value) || 0;
        const cargoType = cargoTypeSelect.value;

        if (weight > 0) { // Allow calculation even without distance for weight-based estimate
            console.log('Calculating cost:', { distance, weight, cargoType });

            // Calculate base cost based on distance and weight
            let cost = (distance * BASE_RATE) + (weight * WEIGHT_RATE);

            // Apply cargo type multiplier if selected
            if (cargoType) {
                cost *= CARGO_MULTIPLIERS[cargoType];
            }

            // Add a minimum charge
            const MIN_CHARGE = 500; // Minimum charge in ETB
            cost = Math.max(cost, MIN_CHARGE);

            // Round to nearest 10 ETB
            cost = Math.ceil(cost / 10) * 10;

            console.log('Calculated cost:', cost);
            amountInput.value = cost.toFixed(2);
        } else {
            console.log('Missing required values:', { distance, weight, cargoType });
        }
    }

    // Add event listeners
    weightInput.addEventListener('input', calculateEstimatedCost);
    cargoTypeSelect.addEventListener('change', calculateEstimatedCost);

    // Expose calculateEstimatedCost to window for map.js to use
    window.calculateEstimatedCost = calculateEstimatedCost;

    // Form validation
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();

            // Check if locations are selected
            if (!window.getDistance()) {
                alert('Please select both pickup and delivery locations on the map.');
                return;
            }

            // Check weight
            const weight = parseFloat(weightInput.value);
            if (isNaN(weight) || weight <= 0) {
                alert('Please enter a valid weight.');
                return;
            }

            // Check cargo type
            if (!cargoTypeSelect.value) {
                alert('Please select a cargo type.');
                return;
            }

            // Check if cost is calculated
            const amount = parseFloat(amountInput.value);
            if (!amount || amount <= 0) {
                alert('Please ensure the estimated cost is calculated correctly.');
                return;
            }

            // If all validations pass, submit the form
            bookingForm.submit();
        });
    }

    // Initialize cost calculation if values are present
    if (weightInput.value && cargoTypeSelect.value) {
        calculateEstimatedCost();
    }
});