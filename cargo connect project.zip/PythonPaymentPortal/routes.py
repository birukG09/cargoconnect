from flask import Flask, render_template, redirect, url_for, request, flash, jsonify
from flask_login import login_required, current_user
from flask_sqlalchemy import SQLAlchemy
# ... other imports ...
import chapa_service # Assuming this module handles Chapa interactions
from datetime import datetime, timedelta

app = Flask(__name__)
# ... other app configurations ...
db = SQLAlchemy(app)

# ... other models ...

class Booking(db.Model):
    # ... booking model fields ...
    payment_status = db.Column(db.String(20), default='pending')
    tracking_status = db.Column(db.String(20))
    current_location = db.Column(db.String(255))
    estimated_delivery = db.Column(db.DateTime)
    status = db.Column(db.String(20), default='pending')
    last_updated = db.Column(db.DateTime, default=datetime.utcnow)
    driver_id = db.Column(db.Integer, db.ForeignKey('driver.id'))
    driver = db.relationship('Driver', backref=db.backref('bookings', lazy=True))


class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey('booking.id'))
    amount = db.Column(db.Float)
    tx_ref = db.Column(db.String(100), unique=True)
    status = db.Column(db.String(20))
    booking = db.relationship('Booking', backref=db.backref('payments', lazy=True))


@app.route('/booking/<int:booking_id>/pay')
@login_required
def process_payment(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != current_user.id:
        flash('Unauthorized access')
        return redirect(url_for('booking_list'))

    if booking.payment_status == 'paid':
        flash('Booking is already paid')
        return redirect(url_for('booking_list'))

    # Generate unique transaction reference
    tx_ref = chapa_service.generate_transaction_reference()

    # Initialize payment with Chapa
    callback_url = url_for('chapa_webhook', _external=True)
    return_url = url_for('booking_list', _external=True)

    try:
        response = chapa_service.initialize_payment(
            amount=booking.amount,
            email=current_user.email,
            first_name=current_user.username,
            last_name='',
            tx_ref=tx_ref,
            callback_url=callback_url,
            return_url=return_url
        )

        if response.get('status') == 'success':
            # Create payment record
            payment = Payment(
                booking_id=booking.id,
                amount=booking.amount,
                tx_ref=tx_ref,
                status='pending'
            )
            db.session.add(payment)
            db.session.commit()

            # Redirect to Chapa payment page
            return redirect(response['data']['checkout_url'])

        flash('Payment initialization failed')
        return redirect(url_for('booking_list'))

    except Exception as e:
        flash(f'Error processing payment: {str(e)}')
        return redirect(url_for('booking_list'))

@app.route('/chapa/webhook', methods=['POST'])
def chapa_webhook():
    payload = request.get_json()
    return chapa_service.handle_charge_webhook(payload)


@app.route("/create_booking", methods=["GET", "POST"])
@login_required
def create_booking():
    if current_user.is_driver():
        flash("Drivers cannot create bookings", "error")
        return redirect(url_for("driver_dashboard"))
    # ... rest of create_booking route ...


# ... rest of the app ...

@app.route('/driver/accept-order/<int:booking_id>', methods=['POST'])
@login_required
def accept_order(booking_id):
    if not current_user.is_driver():
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403

    booking = Booking.query.get_or_404(booking_id)
    
    if booking.status != 'pending' or booking.payment_status != 'paid':
        return jsonify({'success': False, 'message': 'This order is not available for acceptance'}), 400
        
    if booking.driver_id is not None:
        return jsonify({'success': False, 'message': 'This order has already been accepted'}), 400

    try:
        booking.driver_id = current_user.driver_profile.id
        booking.status = 'accepted'
        booking.tracking_status = 'accepted'
        booking.last_updated = datetime.utcnow()
        
        # Update driver availability
        driver = current_user.driver_profile
        driver.available = False
        
        db.session.commit()
        return jsonify({
            'success': True,
            'message': 'Order accepted successfully'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

    try:
        booking.driver_id = current_user.driver_profile.id
        booking.status = 'accepted'
        booking.tracking_status = 'accepted'
        booking.last_updated = datetime.utcnow()
        
        # Update driver availability
        driver = current_user.driver_profile
        driver.available = False
        
        db.session.commit()
        return jsonify({
            'success': True,
            'message': 'Order accepted successfully'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/driver/process-payment/<int:booking_id>')
@login_required
def driver_process_payment(booking_id):
    if not current_user.is_driver():
        flash('Unauthorized access')
        return redirect(url_for('driver_dashboard'))

    booking = Booking.query.get_or_404(booking_id)
    tx_ref = chapa_service.generate_transaction_reference()

    callback_url = url_for('payment_webhook', _external=True)
    return_url = url_for('driver_dashboard', _external=True)

    payment_data = chapa_service.initialize_payment(
        amount=booking.amount,
        email=current_user.email,
        first_name=current_user.username.split()[0],
        last_name=current_user.username.split()[-1] if len(current_user.username.split()) > 1 else '',
        tx_ref=tx_ref,
        callback_url=callback_url,
        return_url=return_url
    )

    if payment_data.get('status') == 'success':
        return redirect(payment_data['data']['checkout_url'])
    else:
        flash('Failed to initialize payment')
        return redirect(url_for('driver_dashboard'))

@app.route('/payment/webhook', methods=['POST'])
def payment_webhook():
    payload = request.get_json()
    return chapa_service.handle_charge_webhook(payload)


@app.route('/api/tracking-status/<int:booking_id>')
@login_required
def get_tracking_status(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != current_user.id and (not current_user.is_driver() or booking.driver_id != current_user.driver_profile.id):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403

    return jsonify({
        'success': True,
        'status': booking.tracking_status,
        'current_location': booking.current_location,
        'estimated_delivery': booking.estimated_delivery.isoformat() if booking.estimated_delivery else None
    })

@app.route('/api/update-tracking', methods=['POST'])
@login_required
def update_tracking():
    if not current_user.is_driver():
        return jsonify({'error': 'Unauthorized'}), 403

    data = request.json
    booking_id = data.get('booking_id')
    status = data.get('status')
    location = data.get('location')
    lat = data.get('latitude')
    lng = data.get('longitude')

    booking = Booking.query.get_or_404(booking_id)
    if booking.driver_id != current_user.driver_profile.id:
        return jsonify({'error': 'Unauthorized'}), 403

    booking.tracking_status = status
    booking.current_location = location
    if lat and lng:
        booking.current_latitude = lat
        booking.current_longitude = lng

    if status == 'picked_up':
        booking.estimated_delivery = datetime.utcnow() + timedelta(hours=24)

    db.session.commit()
    return jsonify({
        'success': True,
        'status': status,
        'location': booking.current_location,
        'lat': lat,
        'lng': lng,
        'estimated_delivery': booking.estimated_delivery.isoformat() if booking.estimated_delivery else None
    })

    if not current_user.is_driver():
        return jsonify({'error': 'Unauthorized'}), 403

    data = request.json
    booking_id = data.get('booking_id')
    status = data.get('status')
    location = data.get('location')

    if not all([booking_id, status]):
        return jsonify({'error': 'Missing required fields'}), 400

    booking = Booking.query.get_or_404(booking_id)
    if booking.driver_id != current_user.driver_profile.id:
        return jsonify({'error': 'Unauthorized'}), 403

    valid_statuses = ['pending', 'picked_up', 'in_transit', 'delivered']
    if status not in valid_statuses:
        return jsonify({'error': 'Invalid status'}), 400

    booking.tracking_status = status
    booking.current_location = location or booking.current_location
    booking.last_updated = datetime.utcnow()

    if status == 'picked_up':
        booking.estimated_delivery = datetime.utcnow() + timedelta(hours=1) # Reduced estimated delivery time
    elif status == 'delivered':
        booking.status = 'completed'
        booking.estimated_delivery = None

    db.session.commit()
    return jsonify({
        'success': True,
        'status': status,
        'location': booking.current_location,
        'estimated_delivery': booking.estimated_delivery.isoformat() if booking.estimated_delivery else None
    })

@app.route('/driver/dashboard')
@login_required
def driver_dashboard():
    if not current_user.is_driver():
        flash("Access denied. Drivers only.", "danger")
        return redirect(url_for("home"))

    driver = Driver.query.filter_by(user_id=current_user.id).first()
    if not driver:
        flash("Driver profile not found.", "danger")
        return redirect(url_for("home"))

    # Get active delivery
    active_delivery = Booking.query.filter_by(
        driver_id=driver.id,
        status='in_progress'
    ).first()

    # Get available paid bookings
    available_bookings = Booking.query.filter_by(
        payment_status='paid',
        driver_id=None,
        status='pending' #added this line to filter only pending bookings
    ).all()

    # Get completed bookings
    completed_bookings = Booking.query.filter_by(
        driver_id=driver.id,
        status='completed'
    ).order_by(Booking.last_updated.desc()).all()

    return render_template("driver/mobile_dashboard.html",
                         active_delivery=active_delivery,
                         available_bookings=available_bookings,
                         completed_bookings=completed_bookings)

if __name__ == '__main__':
    app.run(debug=True)
    