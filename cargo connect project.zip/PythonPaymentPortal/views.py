from flask import render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from models import User, Driver, Booking, Payment
from app import db
from services.chapa_service import ChapaService
from datetime import datetime, timedelta

chapa_service = ChapaService()

def init_routes(app):
    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            try:
                username = request.form.get("username")
                email = request.form.get("email")
                password = request.form.get("password")
                user_type = request.form.get("user_type")

                # Validate required fields
                if not username or not email or not password:
                    flash('Username, email and password are required')
                    return redirect(url_for('register'))

                # Check username length
                if len(username) < 3:
                    flash('Username must be at least 3 characters long')
                    return redirect(url_for('register'))

                # Validate email format
                if '@' not in email or '.' not in email:
                    flash('Please enter a valid email address')
                    return redirect(url_for('register'))

                # Check password length
                if len(password) < 6:
                    flash('Password must be at least 6 characters long')
                    return redirect(url_for('register'))

                # Check if username exists
                if User.query.filter_by(username=username).first():
                    flash('Username already exists. Please choose a different username')
                    return redirect(url_for('register'))

                # Check if email exists
                if User.query.filter_by(email=email).first():
                    flash('Email already registered. Please use a different email')
                    return redirect(url_for('register'))

                # Create user
                user = User(username=username, email=email, role=user_type)
                user.set_password(password)
                db.session.add(user)

                # Handle driver registration
                if user_type == 'driver':
                    license_number = request.form.get('license_number')
                    vehicle_type = request.form.get('vehicle_type')
                    phone = request.form.get('phone')

                    if not all([license_number, vehicle_type, phone]):
                        flash('License number, vehicle type and phone are required for drivers')
                        return redirect(url_for('register'))

                    # Validate phone number (must be numbers only and proper length)
                    if not phone.isdigit() or len(phone) < 10:
                        flash('Please enter a valid phone number (minimum 10 digits)')
                        return redirect(url_for('register'))

                    # Validate license number format
                    if len(license_number) < 5:
                        flash('Please enter a valid license number (minimum 5 characters)')
                        return redirect(url_for('register'))

                    # Check if license exists
                    if Driver.query.filter_by(license_number=license_number).first():
                        flash('License number already registered. Please check and try again')
                        return redirect(url_for('register'))

                    # Check if phone exists
                    if Driver.query.filter_by(phone=phone).first():
                        flash('Phone number already registered. Please use a different number')
                        return redirect(url_for('register'))

                    driver = Driver(
                        user=user,  # This sets the user_id automatically
                        vehicle_type=vehicle_type,
                        license_number=license_number,
                        phone=phone
                    )
                    db.session.add(driver)

                db.session.commit()
                login_user(user)
                flash('Registration successful!')
                return redirect(url_for('home'))  # Changed from 'index' to 'home'

            except Exception as e:
                db.session.rollback()
                print(f"Registration error: {str(e)}")
                flash(f'Registration failed: {str(e)}')
                return redirect(url_for('register'))

        return render_template('register.html')

    @app.route("/")
    def home():
        return render_template("index.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            email = request.form.get("email")
            password = request.form.get("password")
            user = User.query.filter_by(email=email).first()

            if user and user.check_password(password):
                login_user(user)
                flash("Login successful!", "success")
                return redirect(url_for("home"))
            flash("Invalid credentials", "danger")
        return render_template("login.html")

    @app.route("/create_booking", methods=["GET", "POST"])
    @login_required
    def create_booking():
        if current_user.role == 'driver':
            flash("Drivers cannot create bookings", "danger")
            return redirect(url_for("home"))

        if request.method == "POST":
            pickup = request.form.get("pickup_location")
            delivery = request.form.get("delivery_location")
            cargo_type = request.form.get("cargo_type")
            weight = float(request.form.get("weight"))
            amount = float(request.form.get("amount", 0))

            booking = Booking(
                user_id=current_user.id,
                pickup_location=pickup,
                delivery_location=delivery,
                cargo_type=cargo_type,
                weight=weight,
                amount=amount
            )
            db.session.add(booking)
            db.session.commit()

            flash("Booking created successfully!", "success")
            return redirect(url_for("booking_list"))
        return render_template("create_booking.html")

    @app.route("/booking_list")
    @login_required
    def booking_list():
        if current_user.role == 'driver':
            # For drivers, show bookings assigned to them
            driver = Driver.query.filter_by(user_id=current_user.id).first()
            bookings = Booking.query.filter_by(driver_id=driver.id).all() if driver else []
        else:
            # For customers, show their bookings
            bookings = Booking.query.filter_by(user_id=current_user.id).all()
        return render_template("booking_list.html", bookings=bookings)

    @app.route("/profile")
    @login_required
    def profile():
        return render_template("profile.html")

    @app.route("/admin/dashboard")
    @login_required
    def admin_dashboard():
        if not current_user.is_admin:
            flash("Access denied", "danger")
            return redirect(url_for("home"))
        users = User.query.count()
        bookings = Booking.query.count()
        drivers = Driver.query.count()
        recent_bookings = Booking.query.order_by(Booking.created_at.desc()).limit(5).all()
        return render_template(
            "admin/dashboard.html",
            stats={
                "users": users,
                "bookings": bookings,
                "drivers": drivers
            },
            recent_bookings=recent_bookings
        )

    @app.route("/logout")
    @login_required
    def logout():
        logout_user()
        flash("Logged out successfully", "info")
        return redirect(url_for("login"))

    @app.route("/driver/dashboard")
    @login_required
    def driver_dashboard():
        if not current_user.is_driver():
            flash("Access denied. Drivers only.", "danger")
            return redirect(url_for("home"))

        driver = Driver.query.filter_by(user_id=current_user.id).first()
        if not driver:
            flash("Driver profile not found.", "danger")
            return redirect(url_for("home"))

        # Get active delivery (status = 'in_progress')
        active_delivery = Booking.query.filter_by(
            driver_id=driver.id,
            status='in_progress'
        ).first()

        # Get available bookings (status = 'pending', no driver assigned)
        available_bookings = Booking.query.filter_by(
            status='pending',
            driver_id=None
        ).all()

        return render_template("driver/mobile_dashboard.html",
                             active_delivery=active_delivery,
                             available_bookings=available_bookings)

    @app.route("/driver/toggle-availability", methods=["POST"])
    @login_required
    def toggle_availability():
        if not current_user.is_driver():
            return jsonify({"success": False, "message": "Access denied"}), 403

        driver = Driver.query.filter_by(user_id=current_user.id).first()
        if not driver:
            return jsonify({"success": False, "message": "Driver profile not found"}), 404

        data = request.get_json()
        driver.available = data.get('available', False)
        db.session.commit()

        return jsonify({"success": True})

    @app.route("/driver/accept-booking/<int:booking_id>", methods=["POST"])
    @login_required
    def accept_booking(booking_id):
        if not current_user.is_driver():
            return jsonify({"success": False, "message": "Access denied"}), 403

        driver = Driver.query.filter_by(user_id=current_user.id).first()
        if not driver:
            return jsonify({"success": False, "message": "Driver profile not found"}), 404

        booking = Booking.query.get_or_404(booking_id)
        if booking.status != 'pending' or booking.driver_id is not None:
            return jsonify({"success": False, "message": "Booking not available"}), 400

        booking.driver_id = driver.id
        booking.status = 'in_progress'
        db.session.commit()

        return jsonify({"success": True})

    @app.route("/driver/update-status/<int:booking_id>", methods=["POST"])
    @login_required
    def update_booking_status(booking_id):
        if not current_user.is_driver():
            return jsonify({"success": False, "message": "Access denied"}), 403

        driver = Driver.query.filter_by(user_id=current_user.id).first()
        if not driver:
            return jsonify({"success": False, "message": "Driver profile not found"}), 404

        booking = Booking.query.get_or_404(booking_id)
        if booking.driver_id != driver.id:
            return jsonify({"success": False, "message": "Access denied"}), 403

        data = request.get_json()
        new_status = data.get('status')

        if new_status not in ['in_progress', 'completed', 'picked_up', 'delivered']:
            return jsonify({"success": False, "message": "Invalid status"}), 400

        booking.status = new_status
        db.session.commit()

        return jsonify({"success": True})

    @app.route('/booking/<int:booking_id>/pay')
    @login_required
    def process_payment(booking_id):
        booking = Booking.query.get_or_404(booking_id)
        if booking.user_id != current_user.id:
            flash('Unauthorized access')
            return redirect(url_for('booking_list'))

        if booking.payment_status == 'paid':
            flash('Booking is already paid')
            return redirect(url_for('booking_list'))

        # Generate transaction reference
        tx_ref = ChapaService.generate_transaction_reference()

        # Create payment record
        payment = Payment(
            booking_id=booking.id,
            amount=booking.amount,
            tx_ref=tx_ref
        )
        db.session.add(payment)
        db.session.commit()

        # Initialize Chapa payment
        callback_url = url_for('payment_webhook', _external=True)
        return_url = url_for('payment_return', tx_ref=tx_ref, _external=True)

        payment_data = chapa_service.initialize_payment(
            amount=booking.amount,
            email=current_user.email,
            first_name=current_user.username.split()[0],
            last_name=current_user.username.split()[-1] if len(current_user.username.split()) > 1 else '',
            tx_ref=tx_ref,
            callback_url=callback_url,
            return_url=return_url
        )

        if payment_data.get('status') == 'success':
            return redirect(payment_data['data']['checkout_url'])
        else:
            flash('Failed to initialize payment. Please try again.')
            return redirect(url_for('booking_list'))

    @app.route('/payment/webhook', methods=['POST'])
    def payment_webhook():
        payload = request.json
        event = payload.get('event', '')

        if event.startswith('charge.'):
            result = chapa_service.handle_charge_webhook(payload)
            return jsonify(result), 200 if result['status'] == 'success' else 400

        return jsonify({'status': 'error', 'message': 'Invalid event type'}), 400

    @app.route('/tracking/<int:booking_id>')
    @login_required
    def tracking(booking_id):
        booking = Booking.query.get_or_404(booking_id)
        if booking.user_id != current_user.id and (not current_user.is_driver() or booking.driver_id != current_user.driver_profile.id):
            flash('Unauthorized access')
            return redirect(url_for('booking_list'))
        return render_template('tracking.html', booking=booking)

    @app.route('/api/update-tracking', methods=['POST'])
    @login_required
    def update_tracking():
        if not current_user.is_driver():
            return jsonify({'error': 'Unauthorized'}), 403

        data = request.json
        booking_id = data.get('booking_id')
        status = data.get('status')
        location = data.get('location')

        booking = Booking.query.get_or_404(booking_id)
        if booking.driver_id != current_user.driver_profile.id:
            return jsonify({'error': 'Unauthorized'}), 403

        booking.tracking_status = status
        booking.current_location = location
        if status == 'picked_up':
            booking.estimated_delivery = datetime.utcnow() + timedelta(hours=24)

        db.session.commit()
        return jsonify({'success': True})

    @app.route('/payment/return/<tx_ref>')
    @login_required
    def payment_return(tx_ref):
        payment = Payment.query.filter_by(tx_ref=tx_ref).first()
        if not payment:
            flash('Payment not found')
            return redirect(url_for('booking_list'))

        verification = chapa_service.verify_payment(tx_ref)

        if verification.get('status') == 'success':
            flash('Payment successful! Your booking has been confirmed.')
        else:
            flash('Payment verification failed. Please contact support if your payment was deducted.')

        return redirect(url_for('booking_list'))