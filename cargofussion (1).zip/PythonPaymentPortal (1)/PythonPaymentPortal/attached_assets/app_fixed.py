import os
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_migrate import Migrate  # Import Flask-Migrate

# Initialize Flask app
app = Flask(__name__)

# Secret key for sessions
app.secret_key = os.environ.get("SESSION_SECRET", "dev_key")

# Database configuration
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///database.db")  # Default to SQLite
app.config["SQLALCHEMY_DATABASE_URI"] = DATABASE_URL
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize SQLAlchemy
db = SQLAlchemy(app)

# Initialize Flask-Migrate
migrate = Migrate(app, db)

# Set up Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

# Define User model
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), nullable=False, unique=True)
    email = db.Column(db.String(150), nullable=False, unique=True)
    password = db.Column(db.String(150), nullable=False)

class Driver(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    license_number = db.Column(db.String(100), unique=True, nullable=False)

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    driver_id = db.Column(db.Integer, db.ForeignKey('driver.id'), nullable=True)
    pickup_location = db.Column(db.String(255), nullable=False)  # Added pickup_location field
    status = db.Column(db.String(50), nullable=False, default="Pending")

# Flask-Login user loader
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Home route
@app.route("/")
def home():
    return render_template("index.html")

# Login route
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):  # Verify hashed password
            login_user(user)
            flash("Login successful!", "success")
            return redirect(url_for("home"))
        else:
            flash("Invalid credentials, please try again.", "danger")

    return render_template("login.html")

# Register route
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"]

        # Check if user already exists
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("Email already registered. Please log in.", "warning")
            return redirect(url_for("login"))

        # Hash password before storing it
        hashed_password = generate_password_hash(password, method="pbkdf2:sha256")

        new_user = User(username=username, email=email, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        flash("Registration successful! Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")

# Logout route
@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))

# Create Booking Route (Updated to include pickup_location)
@app.route("/create_booking", methods=["GET", "POST"])
@login_required
def create_booking():
    if request.method == "POST":
        pickup_location = request.form.get("pickup_location")  # Get pickup location from form

        if not pickup_location:
            flash("Pickup location is required!", "danger")
            return redirect(url_for("create_booking"))

        new_booking = Booking(user_id=current_user.id, pickup_location=pickup_location, status="Pending")
        db.session.add(new_booking)
        db.session.commit()
        flash("Booking created successfully!", "success")
        return redirect(url_for("home"))

    return render_template("create_booking.html")

# Booking List Route (Fix for Missing booking_list)
@app.route("/booking_list")
@login_required
def booking_list():
    bookings = Booking.query.filter_by(user_id=current_user.id).all()
    return render_template("booking_list.html", bookings=bookings)

# Run the app
if __name__ == "__main__":
    app.run(debug=True)  # Debug mode enabled
