// Initialize the map centered on a default location
let map = null;
let pickupMarker = null;
let deliveryMarker = null;
let routeLine = null;

document.addEventListener('DOMContentLoaded', function() {
    // Initialize map centered on Ethiopia
    map = L.map('map').setView([9.1450, 40.4897], 6);

    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Initialize markers with custom icons
    const markerIcon = L.icon({
        iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
        shadowSize: [41, 41]
    });

    // Handle click events on map
    map.on('click', function(e) {
        const clickedLatLng = e.latlng;

        // If pickup location hasn't been set, set it first
        if (!pickupMarker) {
            pickupMarker = L.marker(clickedLatLng, {icon: markerIcon})
                .bindPopup('Pickup Location')
                .addTo(map);

            // Update the pickup location input
            reverseGeocode(clickedLatLng, 'pickup_location');
        } 
        // If pickup is set but delivery isn't, set delivery
        else if (!deliveryMarker) {
            deliveryMarker = L.marker(clickedLatLng, {icon: markerIcon})
                .bindPopup('Delivery Location')
                .addTo(map);

            // Update the delivery location input
            reverseGeocode(clickedLatLng, 'delivery_location');

            // Draw a line between pickup and delivery
            if (routeLine) {
                map.removeLayer(routeLine);
            }

            const points = [
                pickupMarker.getLatLng(),
                deliveryMarker.getLatLng()
            ];
            routeLine = L.polyline(points, {color: 'blue'}).addTo(map);

            // Trigger cost calculation
            if (typeof window.calculateEstimatedCost === 'function') {
                window.calculateEstimatedCost();
            }
        }
    });

    // Add reset button functionality
    const resetButton = document.createElement('button');
    resetButton.className = 'btn btn-secondary mb-3';
    resetButton.innerHTML = 'Reset Locations';
    resetButton.onclick = resetLocations;
    document.getElementById('map').parentElement.insertBefore(resetButton, document.getElementById('map'));
});

function resetLocations() {
    if (pickupMarker) {
        map.removeLayer(pickupMarker);
        pickupMarker = null;
    }
    if (deliveryMarker) {
        map.removeLayer(deliveryMarker);
        deliveryMarker = null;
    }
    if (routeLine) {
        map.removeLayer(routeLine);
        routeLine = null;
    }
    document.getElementById('pickup_location').value = '';
    document.getElementById('delivery_location').value = '';
    document.getElementById('amount').value = '';
}

// Function to reverse geocode coordinates to address
function reverseGeocode(latlng, inputId) {
    fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latlng.lat}&lon=${latlng.lng}`)
        .then(response => response.json())
        .then(data => {
            if (data && data.display_name) {
                document.getElementById(inputId).value = data.display_name;
                // Trigger cost calculation if delivery location is set
                if (inputId === 'delivery_location' && pickupMarker && deliveryMarker) {
                    if (typeof window.calculateEstimatedCost === 'function') {
                        window.calculateEstimatedCost();
                    }
                }
            }
        })
        .catch(error => {
            console.error('Error reverse geocoding:', error);
            document.getElementById(inputId).value = `${latlng.lat.toFixed(4)}, ${latlng.lng.toFixed(4)}`;
            if (inputId === 'delivery_location' && pickupMarker && deliveryMarker) {
                if (typeof window.calculateEstimatedCost === 'function') {
                    window.calculateEstimatedCost();
                }
            }
        });
}

// Function to calculate distance between two points in kilometers
function calculateDistance() {
    if (pickupMarker && deliveryMarker) {
        return pickupMarker.getLatLng().distanceTo(deliveryMarker.getLatLng()) / 1000;
    }
    return 0;
}

// Export functions for booking.js to use
window.getDistance = calculateDistance;
