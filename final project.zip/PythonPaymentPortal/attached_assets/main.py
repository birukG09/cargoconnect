from . import db


class user(db.model):
  id = db.column(db.integer, primary_key=True)


class driver(db.model):
  id = db.column(db.integer, primary_key=true)
  user_id = db.colum(db.Intger, db.forign_key('user.id'), nullable=False)
  user = db.relationship('user', backref='drivers')
