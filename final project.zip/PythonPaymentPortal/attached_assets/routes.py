from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from app import app, db
from models import User, Driver, Booking, Payment
from services.chapa_service import ChapaService
from werkzeug.security import generate_password_hash
import json

chapa_service = ChapaService()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(email=request.form['email']).first()
        if user and user.check_password(request.form['password']):
            login_user(user)
            return redirect(url_for('index'))
        flash('Invalid email or password')
    return render_template('auth/login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            username = request.form.get('username')
            email = request.form.get('email')
            password = request.form.get('password')
            user_type = request.form.get('user_type')

            # Validate required fields
            if not username or not email or not password:
                flash('Username, email and password are required')
                return redirect(url_for('register'))

            # Check username length
            if len(username) < 3:
                flash('Username must be at least 3 characters long')
                return redirect(url_for('register'))

            # Validate email format
            if '@' not in email or '.' not in email:
                flash('Please enter a valid email address')
                return redirect(url_for('register'))

            # Check password length
            if len(password) < 6:
                flash('Password must be at least 6 characters long')
                return redirect(url_for('register'))

            # Check if username exists
            if User.query.filter_by(username=username).first():
                flash('Username already exists. Please choose a different username')
                return redirect(url_for('register'))
            
            # Check if email exists
            if User.query.filter_by(email=email).first():
                flash('Email already registered. Please use a different email')
                return redirect(url_for('register'))

            # Create user
            user = User(username=username, email=email)
            user.set_password(password)
            db.session.add(user)

            # Handle driver registration
            if user_type == 'driver':
                license_number = request.form.get('license_number')
                vehicle_type = request.form.get('vehicle_type')
                phone = request.form.get('phone')

                if not all([license_number, vehicle_type, phone]):
                    flash('License number, vehicle type and phone are required for drivers')
                    return redirect(url_for('register'))

                # Validate phone number (must be numbers only and proper length)
                if not phone.isdigit() or len(phone) < 10:
                    flash('Please enter a valid phone number (minimum 10 digits)')
                    return redirect(url_for('register'))

                # Validate license number format
                if len(license_number) < 5:
                    flash('Please enter a valid license number (minimum 5 characters)')
                    return redirect(url_for('register'))

                # Check if license exists
                if Driver.query.filter_by(license_number=license_number).first():
                    flash('License number already registered. Please check and try again')
                    return redirect(url_for('register'))

                # Check if phone exists
                if Driver.query.filter_by(phone=phone).first():
                    flash('Phone number already registered. Please use a different number')
                    return redirect(url_for('register'))

                driver = Driver(
                    user=user,
                    name=username,
                    license_number=license_number,
                    vehicle_type=vehicle_type,
                    phone=phone
                )
                db.session.add(driver)

            db.session.commit()
            login_user(user)
            flash('Registration successful!')
            return redirect(url_for('index'))

        except Exception as e:
            db.session.rollback()
            print(f"Registration error: {str(e)}")
            flash(f'Registration failed: {str(e)}')
            return redirect(url_for('register'))

    return render_template('auth/register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/booking/create', methods=['GET', 'POST'])
@login_required
def create_booking():
    if request.method == 'POST':
        booking = Booking(
            user_id=current_user.id,
            pickup_location=request.form['pickup_location'],
            delivery_location=request.form['delivery_location'],
            cargo_type=request.form['cargo_type'],
            weight=float(request.form['weight']),
            amount=float(request.form['amount'])
        )
        db.session.add(booking)
        db.session.commit()
        return redirect(url_for('process_payment', booking_id=booking.id))
    return render_template('booking/create.html')

@app.route('/booking/list')
@login_required
def booking_list():
    bookings = Booking.query.filter_by(user_id=current_user.id).all()
    return render_template('booking/list.html', bookings=bookings)

@app.route('/booking/<int:booking_id>/pay')
@login_required
def process_payment(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != current_user.id:
        flash('Unauthorized access')
        return redirect(url_for('booking_list'))

    if booking.payment_status == 'paid':
        flash('Booking is already paid')
        return redirect(url_for('booking_list'))

    # Generate transaction reference
    tx_ref = ChapaService.generate_transaction_reference()

    # Create payment record
    payment = Payment(
        booking_id=booking.id,
        amount=booking.amount,
        tx_ref=tx_ref
    )
    db.session.add(payment)
    db.session.commit()

    # Initialize Chapa payment
    callback_url = url_for('payment_webhook', _external=True)
    return_url = url_for('payment_return', tx_ref=tx_ref, _external=True)

    payment_data = chapa_service.initialize_payment(
        amount=booking.amount,
        email=current_user.email,
        first_name=current_user.username.split()[0],
        last_name=current_user.username.split()[-1] if len(current_user.username.split()) > 1 else '',
        tx_ref=tx_ref,
        callback_url=callback_url,
        return_url=return_url
    )

    if payment_data.get('status') == 'success':
        return redirect(payment_data['data']['checkout_url'])
    else:
        flash('Failed to initialize payment. Please try again.')
        return redirect(url_for('booking_list'))

@app.route('/payment/webhook', methods=['POST'])
def payment_webhook():
    payload = request.json
    event = payload.get('event', '')
    
    if event.startswith('charge.'):
        result = chapa_service.handle_charge_webhook(payload)
    elif event.startswith('payout.'):
        result = chapa_service.handle_payout_webhook(payload)
    else:
        result = {'status': 'error', 'message': 'Invalid event type'}
        
    return jsonify(result), 200 if result['status'] == 'success' else 400

    # Verify the payment
    tx_ref = payload.get('tx_ref')
    if not tx_ref:
        return jsonify({'status': 'error', 'message': 'Missing tx_ref'}), 400

    payment = Payment.query.filter_by(tx_ref=tx_ref).first()
    if not payment:
        return jsonify({'status': 'error', 'message': 'Payment not found'}), 404

    verification = chapa_service.verify_payment(tx_ref)

    if verification.get('status') == 'success':
        payment.status = 'completed'
        payment.chapa_transaction_id = verification['data']['transaction_id']
        payment.booking.payment_status = 'paid'
        payment.booking.status = 'confirmed'
        db.session.commit()

        return jsonify({'status': 'success'}), 200

    return jsonify({'status': 'error', 'message': 'Payment verification failed'}), 400

@app.route('/payment/return/<tx_ref>')
@login_required
def payment_return(tx_ref):
    payment = Payment.query.filter_by(tx_ref=tx_ref).first()
    if not payment:
        flash('Payment not found')
        return redirect(url_for('booking_list'))

    verification = chapa_service.verify_payment(tx_ref)

    if verification.get('status') == 'success':
        flash('Payment successful! Your booking has been confirmed.')
    else:
        flash('Payment verification failed. Please contact support if your payment was deducted.')

    return redirect(url_for('booking_list'))

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    bookings = Booking.query.all()
    drivers = Driver.query.all()
    return render_template('admin/dashboard.html', bookings=bookings, drivers=drivers)

@app.route('/driver/dashboard')
@login_required
def driver_dashboard():
    # Get the driver profile for the current user
    driver = Driver.query.filter_by(user_id=current_user.id).first()
    if not driver:
        flash('Driver profile not found')
        return redirect(url_for('index'))
    
    # Get active and completed bookings
    active_bookings = Booking.query.filter_by(
        driver_id=driver.id
    ).filter(Booking.status.in_(['pending', 'in_progress'])).all()
    
    completed_bookings = Booking.query.filter_by(
        driver_id=driver.id, status='completed'
    ).all()
    
    # Calculate total earnings
    total_earnings = sum(booking.amount for booking in completed_bookings)
    
    return render_template('driver/dashboard.html',
                         active_bookings=active_bookings,
                         completed_bookings=completed_bookings,
                         total_earnings=total_earnings)

@app.route('/booking/<int:booking_id>/status', methods=['POST'])
@login_required
def update_booking_status(booking_id):
    driver = Driver.query.filter_by(user_id=current_user.id).first()
    if not driver:
        flash('Unauthorized access')
        return redirect(url_for('index'))
        
    booking = Booking.query.get_or_404(booking_id)
    if booking.driver_id != driver.id:
        flash('Unauthorized access')
        return redirect(url_for('driver_dashboard'))
        
    new_status = request.form.get('status')
    if new_status in ['completed', 'in_progress']:
        booking.status = new_status
        db.session.commit()
        flash(f'Booking status updated to {new_status}')
    
    return redirect(url_for('driver_dashboard'))

@app.route('/admin/drivers', methods=['GET', 'POST'])
@login_required
def manage_drivers():
    if not current_user.is_admin:
        return redirect(url_for('index'))

    if request.method == 'POST':
        driver = Driver(
            name=request.form['name'],
            vehicle_type=request.form['vehicle_type'],
            license_number=request.form['license_number'],
            phone=request.form['phone']
        )
        db.session.add(driver)
        db.session.commit()
        return redirect(url_for('manage_drivers'))

    drivers = Driver.query.all()
    return render_template('admin/drivers.html', drivers=drivers)