from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, FloatField, SelectField
from wtforms.validators import DataRequired, Email, Length

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])

class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=50)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])

class BookingForm(FlaskForm):
    pickup_location = StringField('Pickup Location', validators=[DataRequired()])
    delivery_location = StringField('Delivery Location', validators=[DataRequired()])
    cargo_type = SelectField('Cargo Type', choices=[
        ('general', 'General Cargo'),
        ('perishable', 'Perishable Goods'),
        ('fragile', 'Fragile Items'),
        ('heavy', 'Heavy Equipment')
    ])
    weight = FloatField('Weight (kg)', validators=[DataRequired()])
